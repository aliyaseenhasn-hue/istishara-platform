---
name: Nocturne Counsel
colors:
  surface: '#16130b'
  surface-dim: '#16130b'
  surface-bright: '#3d392f'
  surface-container-lowest: '#110e07'
  surface-container-low: '#1f1b13'
  surface-container: '#231f17'
  surface-container-high: '#2d2a21'
  surface-container-highest: '#38342b'
  on-surface: '#eae1d4'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#eae1d4'
  inverse-on-surface: '#343027'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#45d8ed'
  on-secondary: '#00363d'
  secondary-container: '#00bacd'
  on-secondary-container: '#00444d'
  tertiary: '#bfcdff'
  on-tertiary: '#082b72'
  tertiary-container: '#97b0ff'
  on-tertiary-container: '#254188'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#98f0ff'
  secondary-fixed-dim: '#45d8ed'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#27438a'
  background: '#16130b'
  on-background: '#eae1d4'
  surface-variant: '#38342b'
typography:
  headline-xl:
    fontFamily: Domine
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Domine
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Domine
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The design system is a high-end, dark-mode focused interface tailored for the legal and academic sectors. It evokes a sense of quiet authority, intellectual depth, and unwavering reliability. The brand personality is "The Modern Magistrate"—sophisticated, precise, and serious without being archaic.

The visual style is **Corporate Modern with a Minimalist focus**. It utilizes deep, immersive backgrounds to reduce eye strain during long-form reading, paired with high-contrast typography and subtle "Glassmorphic" accents to signify premium quality. The interface prioritizes clarity of information over decorative flourish, ensuring that legal narratives remain the central focus.

## Colors

This design system utilizes a sophisticated dark palette designed for high-stakes professional environments.

*   **Primary (Gold):** Used sparingly for high-level emphasis, branding elements, and primary call-to-actions. It represents excellence and heritage.
*   **Secondary (Cyan/Teal):** Used for interactive states, text links, and data visualization. It provides a modern, digital counterpoint to the traditional gold.
*   **Base Tones:** The background uses a Deep Navy (#0A1929) to provide a stable, low-glare foundation. Surfaces and containers use a slightly elevated Navy (#102A43) to create a clear visual hierarchy.
*   **Typography Colors:** Off-white is reserved for headings to ensure maximum impact, while light gray is used for body text to maintain a comfortable reading contrast ratio of at least 7:1.

## Typography

The typography strategy pairs an authoritative serif for headings with a highly legible, grounded sans-serif for functional text.

*   **Headlines:** Domine provides a sturdy, traditional "legal" feel that carries weight and credibility.
*   **Body:** Work Sans is utilized for its neutral, straightforward character, ensuring that dense legal text remains accessible and easy to digest.
*   **Technical Labels:** JetBrains Mono is used for metadata, citations, and status labels to provide a precise, organized, and slightly technical aesthetic.

## Layout & Spacing

The design system employs a **Fixed Grid** system for desktop to maintain the structural integrity of complex documents, transitioning to a fluid layout for mobile devices.

*   **Desktop:** A 12-column grid with a 1280px max-width. Large 40px margins create a "stage" for content, reflecting a premium editorial feel.
*   **Tablet:** An 8-column grid with 24px gutters.
*   **Mobile:** A 4-column fluid grid.
*   **Rhythm:** Vertical rhythm is based on an 8px baseline. Large sections of text should utilize generous white space (32px - 64px) between major thematic blocks to prevent cognitive overload.

## Elevation & Depth

Hierarchy in this design system is achieved through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

*   **Surface Tiers:** Level 0 is the background. Level 1 (Surfaces) uses the secondary navy. Level 2 (Modals/Popovers) uses an even lighter navy with a subtle 1px border (#243B53).
*   **Outlines:** All containers should feature a subtle, low-opacity border. Avoid drop shadows on primary cards; use them only for floating elements (like dropdowns) using a deep, tinted navy shadow with a high blur (20px+) and low opacity (40%).
*   **Glassmorphism:** For top navigation bars or floating action panels, use a backdrop-filter (blur: 12px) with a semi-transparent version of the surface color to maintain context of the content beneath.

## Shapes

The shape language is **Soft (Level 1)**. 

Elements use a consistent 0.25rem (4px) corner radius. This choice strikes a balance between the "sharp" traditional legal look and a modern, approachable software feel. It communicates precision without the aggressive nature of perfectly square corners. Interactive elements like buttons and input fields follow this 4px rule, while larger sections or containers may scale up to 8px (rounded-lg) for a more architectural feel.

## Components

*   **Buttons:** Primary buttons use the Gold (#D4AF37) background with dark navy text. Secondary buttons are outlined in Cyan (#26C6DA) with Cyan text.
*   **Input Fields:** Deep navy background with a 1px border that glows Cyan (#26C6DA) on focus. Labels use JetBrains Mono in light gray.
*   **Cards:** Use the Surface color (#102A43) with a subtle border. There is no shadow; depth is communicated solely through the color shift from the background.
*   **Chips/Tags:** Small, pill-shaped markers using JetBrains Mono. Use Cyan for "Active" or "Open" statuses and a muted gray for "Closed" or "Historical."
*   **Lists:** Legal lists (bulleted/numbered) should have increased line-height (1.6) and dedicated padding to distinguish between clauses.
*   **Citations:** Blockquotes should feature a 2px vertical Gold line on the left, with text in Domine Italic to emphasize authoritative references.