---
name: Istishara Glass-Legal
colors:
  surface: '#111415'
  surface-dim: '#111415'
  surface-bright: '#373a3b'
  surface-container-lowest: '#0c0f10'
  surface-container-low: '#191c1d'
  surface-container: '#1d2021'
  surface-container-high: '#282a2b'
  surface-container-highest: '#323536'
  on-surface: '#e1e3e4'
  on-surface-variant: '#c2c7ce'
  inverse-surface: '#e1e3e4'
  inverse-on-surface: '#2e3132'
  outline: '#8c9198'
  outline-variant: '#42474d'
  surface-tint: '#a5cbed'
  primary: '#a5cbed'
  on-primary: '#03334f'
  primary-container: '#113c58'
  on-primary-container: '#81a7c7'
  inverse-primary: '#3c6280'
  secondary: '#e9c349'
  on-secondary: '#3c2f00'
  secondary-container: '#af8d11'
  on-secondary-container: '#342800'
  tertiary: '#87d5c5'
  on-tertiary: '#003730'
  tertiary-container: '#004138'
  on-tertiary-container: '#62b0a1'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#cbe6ff'
  primary-fixed-dim: '#a5cbed'
  on-primary-fixed: '#001e31'
  on-primary-fixed-variant: '#234a67'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#a3f1e0'
  tertiary-fixed-dim: '#87d5c5'
  on-tertiary-fixed: '#00201b'
  on-tertiary-fixed-variant: '#005046'
  background: '#111415'
  on-background: '#e1e3e4'
  surface-variant: '#323536'
  gradient-start: '#113C58'
  gradient-mid: '#1D6B8C'
  gradient-accent: '#56A495'
  gold-accent: '#D4AF37'
  glass-fill: rgba(255, 255, 255, 0.05)
  glass-border: rgba(255, 255, 255, 0.1)
typography:
  display-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 44px
  headline-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.15em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 20px
  margin-mobile: 24px
  margin-desktop: 80px
---

## Brand & Style
The brand identity for Istishara is authoritative yet modern, designed to evoke trust, stability, and transparency in the legal sector. The UI employs a **Glassmorphic** style layered over a dynamic, professional gradient. This approach balances the serious nature of legal consultation with a forward-thinking, digital-first experience.

The visual language is characterized by:
- **Atmospheric Depth:** The use of an animated ambient background and large, low-opacity geometric shapes creates a sense of space and sophistication.
- **Translucent Surfaces:** "Glass panels" provide hierarchy without disconnecting the user from the overall brand environment.
- **High-End Contrast:** Gold accents against deep teal and navy tones signal prestige and reliability (the Iraqi legal/institutional palette).

## Colors
The palette is built on a "Deep Sea" foundation with "Legal Gold" accents.
- **Primary Palette:** Deep teals and navy blue (#113C58 to #1D6B8C) represent authority and the institutional weight of the law.
- **Secondary Accent:** A sophisticated gold (#D4AF37) is used for primary calls to action and key brand elements, signifying quality and value.
- **Tertiary Palette:** A muted sage (#56A495) provides visual relief and modern flair within the background gradients.
- **Surface Strategy:** Backgrounds are never solid; they are either the animated `ambient-bg` gradient or `glass-panel` overlays. All text on these backgrounds should maintain high legibility using white or off-white with varying opacities.

## Typography
The system uses **IBM Plex Sans Arabic** across all roles to ensure a structured, technical, yet highly readable experience. 
- **Display & Headlines:** Use bold weights and tight letter spacing for a commanding presence. 
- **Bilingual Context:** The design supports RTL as primary, with specific English sub-branding (`label-sm`) using high tracking/letter-spacing for a luxury-tier appearance.
- **Body Text:** Kept clean and high-contrast (white at 90% opacity) to ensure comfort on dark, blurred backgrounds.

## Layout & Spacing
The layout follows a **Fluid Grid** approach for mobile, transitioning to a **Fixed Grid** for desktop centered content.
- **Vertical Rhythm:** A 4px/8px baseline is used. Large sections (like the logo to form transition) use `xl` (64px) spacing to maintain an airy, premium feel.
- **Safe Areas:** Mobile screens require a minimum 24px side margin (`margin-mobile`).
- **Input Spacing:** A standard 56px height (14 units) is used for primary inputs and buttons to ensure touch-friendly targets.

## Elevation & Depth
Depth is not communicated through traditional drop shadows, but through **Glassmorphism** and **Z-axis Layering**:
- **Layer 0 (Background):** Animated 4-color linear gradient with moving background-position.
- **Layer 1 (Atmospheric):** Large, semi-transparent white stroke circles positioned absolutely to break the grid and add organic depth.
- **Layer 2 (Panels):** Semi-transparent surfaces (`rgba(255, 255, 255, 0.05)`) with a 10px backdrop blur and a 1px solid border (`rgba(255, 255, 255, 0.1)`).
- **Layer 3 (Interactive):** Elements like the primary button use high-saturation solid colors (Gold) and a `shadow-lg` to "lift" off the glass panels.

## Shapes
The shape language is "Soft-Modern."
- **Standard Radius:** Elements like input fields and glass panels use a 12px (0.75rem / `rounded-xl`) radius.
- **Small Elements:** Icons or small chips use a 8px (`rounded-lg`) radius.
- **Dividers:** Use a 1px high line with 20% white opacity to maintain the glass aesthetic without creating hard visual breaks.

## Components
- **Primary Button:** Solid `gold-accent` fill. Text is high-contrast dark navy. Uses a subtle scale-down (98%) on active states for a tactile "squish" feel.
- **Glass Inputs:** Background uses `glass-fill` with `glass-border`. On focus, the background opacity increases slightly and the border color shifts toward the gold accent.
- **Iconography:** Use "Material Symbols Outlined" with a weight of 400. In specific branded contexts (like the logo), use the "Filled" variant to create a focal point.
- **Dividers:** Horizontal rules should be `white/20`. If text is present within the divider (e.g., "OR"), it should be centered with equal line weights on both sides.
- **Social Login:** Follows the glass panel style but maintains the original brand colors for the logos (e.g., Google's multicolor G) to ensure instant recognition.